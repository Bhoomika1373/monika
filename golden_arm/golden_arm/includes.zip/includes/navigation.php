<header id="header" class="header d-flex align-items-center fixed-top">
  <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">
    <nav id="navmenu" class="navmenu">
      <ul>
        <li><a href="/golden_arm/home" class="item-home"><i class="bi bi-house-fill"></i></a></li>
        <li><a href="/golden_arm/menu" class="item-menu">Menu</a></li>
        <li><a href="/golden_arm/pickup" class="item-pickup">Pickup</a></li>
        <li><a href="/golden_arm/reservation" class="item-reservation">Reservation</a></li>
      </ul>
    </nav>
  </div>
</header>
